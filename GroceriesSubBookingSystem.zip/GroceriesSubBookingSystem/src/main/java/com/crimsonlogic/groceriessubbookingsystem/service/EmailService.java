package com.crimsonlogic.groceriessubbookingsystem.service;

public class EmailService {

}
